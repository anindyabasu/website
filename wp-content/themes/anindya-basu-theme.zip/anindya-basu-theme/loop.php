<?php if (have_posts()): while (have_posts()) : the_post(); ?>
    <div class="post-wrapper">
        <aside class="post-info">
        <span class="by"><?php _e( 'by', 'html5blank' ); ?></span>
        <span class="author"><?php the_author(); ?></span>
        <span class="date"><?php the_time('m/d/Y'); ?></span>
        <span class="comments-count"><?php comments_number(); ?></span>
        <span><a id="share-<?php the_ID(); ?>" class="share">Share</a></span>
        <div id="toggleText-<?php the_ID(); ?>" class = "toggle-text" style="display: none;">
        <a class="sharelink facebook" href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&t=<?php the_title(); ?>"
        onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
        target="_blank" title="Share on Facebook">Facebook</a>
        <a class="sharelink twitter" href="https://twitter.com/share?url=<?php the_permalink();?>&t=<?php the_title(); ?>&via=Parts.io&text=<?php the_title(); ?>"
        onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
        target="_blank" title="Share on Twitter">Twitter</a>
        <a class="sharelink google" href="https://plus.google.com/share?url=<?php the_permalink();?>"
        onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=350,width=480');return false;"
        target="_blank" title="Share on Google+">Google</a>
        </div>
        </aside>
        <!-- article -->
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

            <!-- post title -->
            <h2>
                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
            </h2>
            <!-- /post title -->
            <!-- post thumbnail -->
            <?php if ( has_post_thumbnail()) : // Check if thumbnail exists ?>
                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                    <?php the_post_thumbnail(array(120,120)); // Declare pixel size you need inside the array ?>
                </a>
            <?php endif; ?>
            <!-- /post thumbnail -->


            <?php the_content('Read More...'); // Dynamic Content ?>

            <?php edit_post_link(); ?>

        </article>
        <!-- /article -->
 
    </div>
<?php endwhile; ?>

<?php else: ?>

	<!-- article -->
	<article>
		<h2><?php _e( 'Sorry, nothing to display.', 'html5blank' ); ?></h2>
	</article>
	<!-- /article -->

<?php endif; ?>
