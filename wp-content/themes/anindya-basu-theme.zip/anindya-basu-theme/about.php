<?php
/*
 *Template Name: About Me
 *Description: Theme for About Me page
*/
?>
<?php get_header(); ?>
<main>
    <div id="about-text">
        <h3>About Me</h3>
        <p>Hey there, I'm <b>Anindya</b>.</p>
        <p>I'm a <b>front end engineer</b> and a <b>foodie</b> who's passionate about Human Computer Interaction and User Experience Design and Implementation.</p>
        <p>I have plenty of experience using <b>Javascript</b>, <b>HTML</b>, and <b>CSS</b>.</p>
        <p>In addition to those, I'm well versed with Photoshop, Node.js, SASS, Compass, Wordpress, and Selenium.</p>
        <p>I come from a computer science and graphic design background. My coding chops and strong design sense allow me to walk the fine line that is HCI and UX with ease. Feel free to peruse my projects, read some of my blog posts about food and UX, or check me out on my social media sites.</p>
    </div>
    <div id="education" class="right">
        <h3>Education</h3>
        <p><span>UC San Diego</span> B.S. Computer Science, 2016</p>
    </div>
    <div id="work-experience" class="right">
        <h3>Work Experience</h3>
        <table>
            <tr>
                <td>2014</td>
                <td>SupplyFrame</td>
                <td>Front End Intern</td>
            </tr>
            <tr>
                <td>2013</td>
                <td>Warren College, UCSD</td>
                <td>Graphic Design Intern</td>
            </tr>
            <tr>
                <td>2012</td>
                <td>Kenya Solar Demonstration</td>
                <td>Team Lead</td>
            </tr>
            <tr>
                <td>2012</td>
                <td>Warren College, UCSD</td>
                <td>Orientation Leader</td>
            </tr>
            <tr>
                <td>2010</td>
                <td>Nymbys</td>
                <td>UI Intern/Alpha Tester</td>
            </tr>
        </table>
        <h5>abasu@ucsd.edu  <a href="http://www.anindyabasu.com/resume.pdf" download="AnindyaBasuResume">Resume</a> <a href="http://www.linkedin.com/in/anindyabasu5/">LinkedIn</a>  <a href="http://stackoverflow.com/users/3565495/anindya-basu">StackOverflow</a>  <a href="https://github.com/anindyabasu">GitHub</a></h5>
    </div>
    <?php echo do_shortcode("[insta_team photos=7 class=ig-feed]"); ?>
    <p id="instagram-link">View more on my <a href="http://www.instagram.com/anindya_basu">Instagram →</a></p>
</main>
<?php get_footer(); ?>
