jQuery(document).ready(function($) {
    $(".share").click(function() {
        var id = $(this).attr('id').split("-")[1];
        $("#toggleText-" + id).slideToggle();
        $("#share-" + id).toggleClass("share-active");
    });
    
    $(".menu-icon").click(function() {
        $("nav").slideToggle();
    });
}); 