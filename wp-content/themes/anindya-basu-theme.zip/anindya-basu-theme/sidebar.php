<!-- sidebar -->
<aside class="sidebar" role="complementary">
	<div class="sidebar-widget">
		<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-area-1')) ?>
    </div>
    <script type="text/javascript">

        var icpForm1156 = document.getElementById('icpsignup1156');

        if (document.location.protocol === "https:") {
          icpForm1156.action = "https://app.icontact.com/icp/signup.php";
        }

        function verifyRequired1156() {
            if (icpForm1156["fields_email"].value == "") {
                icpForm1156["fields_email"].focus();
                alert("The Email field is required.");
                return false;
            }

            return true;
        }
    </script>
</aside>
<!-- /sidebar -->
