<?php get_header(); ?>

	<main role="main">
		<!-- section -->
		<section>

			<!-- article -->
			<article id="post-404" class="post-404">
                <div class="header-text">
                    <h1>I'm <span>Anindya Basu</span>.</h1>
                    <p>This site is currently under construction</p>
                    <br>
                    <p>You can see what I've been up to on my&nbsp;</p>
                    <a href="https://github.com/anindyabasu">GitHub</a>
                    <br>
                    <p>Or check out my food adventures on&nbsp;</p>
                    <a href="http://instagram.com/anindya_basu">Instagram</a>
                </div>

			</article>
			<!-- /article -->

		</section>
		<!-- /section -->
	</main>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
