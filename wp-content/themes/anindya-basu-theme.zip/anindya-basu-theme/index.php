<?php get_header(); ?>
<main class="blog">
    <?php if (have_posts()): while (have_posts()) : the_post(); ?>
    <div class="post-wrapper">
    
        <!-- article -->
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

            <!-- post title -->
            <h2>
                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
            </h2>
            <!-- /post title -->
            <!-- post details -->
            <div class="post-info">
                <span class="date"><?php the_time('m/d/Y'); ?></span>
                <span class="comments-count"><?php comments_number(); ?></span>
            </div>
            <!-- post thumbnail -->
            <?php if ( has_post_thumbnail()) : // Check if thumbnail exists ?>
            <div class="featured-pic">
                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                    <?php the_post_thumbnail(array(1000,400)); // Declare pixel size you need inside the array ?>
                </a>
            </div>
            <?php endif; ?>
            <!-- /post thumbnail -->

            <?php the_content('Read More...'); // Dynamic Content ?>

            <?php edit_post_link(); ?>

        </article>
        <!-- /article -->

    </div>
    <?php endwhile; ?>

    <?php else: ?>

    <!-- article -->
    <article>
        <h2><?php _e( 'Sorry, nothing to display.', 'html5blank' ); ?></h2>
    </article>
    <!-- /article -->

    <?php endif; ?>

</main>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
