Theme made using [HTML5 Blank](http://html5blank.com), visit site for documentation on theme. 

To install, clone these files into the wordpress/wp-content/themes/ folder

wordpress admin username: admin

password: 5d6w1qp04w 
