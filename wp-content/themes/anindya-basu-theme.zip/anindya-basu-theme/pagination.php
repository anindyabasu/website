<!-- pagination -->
<div class="pagination">
    <?php posts_nav_link( '  ', '<img src="' . get_bloginfo('stylesheet_directory') . '/img/icons/prev-page@2x.png" class="arrow-prev prev" /><p class="prev prev-text">Previous</p>', '<img src="' . get_bloginfo('stylesheet_directory') . '/img/icons/next-page@2x.png" class="arrow-next next" /><p class="next next-text">Next Page</p>'); ?>
</div>
<!-- /pagination -->
